export LD_LIBRARY_PATH=`pwd`
./init_ndeb_sample
